export class calculator
{
  x:number;
  y:number;
  constructor(a:number,b:number)
  {
    this.x=a;
	this.y=b;
  }
  sum()
   {
     console.log(this.x+this.y);	 
   }
  sub()
   {
     console.log(this.x-this.y);	 
   } 
   mul()
   {
     console.log(this.x*this.y);	 
   }
}
export class demo
{
	show()
	{
		console.log("demo method show");		
	}
}