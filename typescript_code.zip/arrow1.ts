var max=(n1:number,n2:number):number=>
{
 var t:number;
  if(n1>n2)
     t= n1;
  else
	t=n2;
	return t;
}
console.log(max(10,23));
var show=()=> console.log("this is arrow function without parameter");

show();

var sum=(a:number, b:number)=> a+b;

console.log(sum(12,23));

