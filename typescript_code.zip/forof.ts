var a=[10,23,33,23,45];
for (var x of a)
  console.log(x);

for (var i in a)
  console.log("index :- "+i+ "-- value  "+a[i]);