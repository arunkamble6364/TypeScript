import {calculator,demo} from './MyModule';

var objcalc = new calculator(10,20);
objcalc.sum();
objcalc.sub();
objcalc.mul();
var objdemo = new demo();
objdemo.show();