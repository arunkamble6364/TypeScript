var anil=function():void
{
  console.log("Hello from Anonymous function");
}
var m2=function(n:number, m:number):number{
	
	return (n+m);
}

anil();
console.log(m2(10,34));