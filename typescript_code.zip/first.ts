var msg="hello how are you ";
console.log(msg);
var a=null;
console.log(a);// null 
console.log(typeof(a)); // Object

var b;
console.log(b);
console.log(typeof(b));