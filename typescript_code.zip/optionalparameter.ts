function data(id:number,name:string,passport?:string):void
{
  console.log("Name:-"+ name);
  console.log("id:-"+ id);
  if(passport!=undefined)
  console.log("passport:-"+ passport);
  
}
data(101,"sunil kumar");
data(102,"anil kumar","IND22-212345");