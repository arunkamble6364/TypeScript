class item
{
  itemid:number;
  itemname:string;
  constructor(id:number,name:string)
  {
    this.itemid=id;
	this.itemname=name;
  }
  printdata()
  {
   console.log(this.itemid);
   console.log(this.itemname);
  }
  printId=()=>console.log(this.itemid);
}
var obj = new item(102,"shirt");
obj.printdata();
obj.printId();
var d:any;