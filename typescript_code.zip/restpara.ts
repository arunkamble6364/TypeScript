//rest parameter
/*function max(a:number,...b:number[]):void
{
  console.log("you will se maxium of list & value of "+a);
  var x;
  x=b[0];
  var i;
  for(i=1;i<b.length;i++)
	    if(b[i]>x)
			 x=b[i];

 console.log("Maximum:- "+x);
}
max(10,23,56,789,90,97); */
function max(...b:number[]):void
{
  console.log("you will se maxium of list ");
  var x;
  x=b[0];
  var i;
  for(i=1;i<b.length;i++)
	    if(b[i]>x)
			 x=b[i];

 console.log("Maximum:- "+x);
}
max(102,32,33,232,234,567);