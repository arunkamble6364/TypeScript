function show():void{
	var d=200;
let x=100;
 if(x>50)
   {
     let y=x+1;
	 var z=23;
	 console.log(y);
   }
 console.log(d);
 console.log(z);
}
show();
 