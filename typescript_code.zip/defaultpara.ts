function hikesalary(empid:number,empname:string, hike:number=10):void
{
  console.log("empid:- "+ empid);
  console.log("empname:- "+ empname);
  console.log("Hike in salary:- "+ hike);
}
hikesalary(101,"sunil kumar",14);
hikesalary(102,"anil kumar");
hikesalary(103,"ajay kumar",20);